<?php

use Illuminate\Support\Facades\Route;
/*
|--------------------------------------------------------------------------
| Manager Routes
|--------------------------------------------------------------------------
|
| Here is where you can register manager routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "manager" middleware group. Now create something great!
|
*/