(function($) {
    "use strict"

    new dlabSettings({
        sidebarStyle: "mini"
    });


})(jQuery);