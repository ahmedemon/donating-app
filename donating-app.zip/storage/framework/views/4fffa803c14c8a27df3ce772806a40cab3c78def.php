<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- PAGE TITLE HERE -->
    <title><?php echo e('Donate For Re-Use | ' . ($pageTitle ?? 'User Panel')); ?></title>
    <!-- FAVICONS ICON -->
    <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('favicon.png')); ?>" />
    <link href="<?php echo e(asset('backend/vendor/jquery-nice-select/css/nice-select.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('backend/vendor/owl-carousel/owl.carousel.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('backend/vendor/toastr/css/toastr.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backend/vendor/sweetalert2/dist/sweetalert2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backend/icons/font-awesome/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/logo_animation.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- Style css -->
    <link href="<?php echo e(asset('backend/css/style.css')); ?>" rel="stylesheet">
    <style>
        ::-webkit-scrollbar {
            width: 10px;
            height: 10px;
            border-radius: 50%;
        }

        ::-webkit-scrollbar-track {
            border-radius: 10px;
        }

        ::-webkit-scrollbar-thumb {
            background: rgb(87, 87, 87);
            border-radius: 10px;
        }

        .form-control.is-invalid {
            border-top-right-radius: 1rem !important;
            border-bottom-right-radius: 1rem !important;
        }

        [data-sidebar-style="full"][data-layout="vertical"] .dlabnav .metismenu>li>a {
            padding: 0.55rem 2.1875rem;
        }

        .card-body {
            z-index: 0 !important;
        }
    </style>

    <?php echo $__env->yieldPushContent('css'); ?>

    <?php if(Request::is('user')): ?>
        <link rel="stylesheet" href="<?php echo e(asset('backend/css/style.ext.css')); ?>">
    <?php endif; ?>

</head>

<body class="<?php echo e(Request::is('login') || Request::is('password/*') || !Request::is('guest/register') ? 'vh-100' : ''); ?>">

    <?php if(!Request::is('login') && !Request::is('password/*') && !Request::is('register')): ?>
        <!-- Preloader start -->
        <div id="preloader">
            <div class="lds-ripple">
                <div></div>
                <div></div>
            </div>
        </div>
        <!-- Preloader end -->

        <!-- Main  -->
        <div id="main-wrapper">
            <!-- Nav  -->
            <?php if(auth()->guard()->check()): ?>
                <div class="nav-header">
                    <a href="<?php echo e(route('user.dashboard')); ?>" class="brand-logo">
                        <img style="height: 60%; width: 100%;" class="border rounded" src="<?php echo e(asset('logo.png')); ?>" alt="Logo">
                    </a>
                    <div class="nav-control d-lg-none">
                        <div class="hamburger">
                            <span class="line"></span><span class="line"></span><span class="line"></span>
                        </div>
                    </div>
                </div>
                <!-- Nav  -->

                <!-- Header start -->
                <div class="header">
                    <div class="header-content" style="padding-left: 0rem;">
                        <nav class="navbar navbar-expand">
                            <div class="collapse navbar-collapse justify-content-between">
                                    <marquee behavior="" direction="">Notice Slider</marquee>
                                <div class="header-left">
                                </div>
                                <?php echo $__env->make('layouts.user.header-right', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </nav>
                    </div>
                </div>
                <!-- Header end -->
                <!-- Sidebar start -->
                <?php echo $__env->make('layouts.user.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- Sidebar end -->

            <?php endif; ?>
            <!-- Content body start -->
            <div class="content-body">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
            <!-- Content body end -->


        </div>
        <!--
        Main wrapper end -->
    <?php else: ?>
        <?php echo $__env->yieldContent('content'); ?>
    <?php endif; ?>

    <!-- Scripts -->
    <!-- Required vendors -->
    <script src="<?php echo e(asset('backend/vendor/global/global.min.js')); ?>"></script>

    <?php if(!Request::is('login')): ?>

        <script src="<?php echo e(asset('backend/vendor/jquery-nice-select/js/jquery.nice-select.min.js')); ?>"></script>


        <?php if(Request::is('user/wallet*')): ?>
            <!-- Apex Chart -->
            <script src="<?php echo e(asset('backend/vendor/apexchart/apexchart.js')); ?>"></script>
            <script src="<?php echo e(asset('backend/vendor/chart.js/Chart.bundle.min.js')); ?>"></script>
            <!-- Chart piety plugin files -->
            <script src="<?php echo e(asset('backend/vendor/peity/jquery.peity.min.js')); ?>"></script>
            <script src="<?php echo e(asset('backend/js/dashboard/dashboard-1.js')); ?>"></script>
        <?php endif; ?>
        <!-- Dashboard 1 -->

        <script src="<?php echo e(asset('backend/vendor/owl-carousel/owl.carousel.js')); ?>"></script>

    <?php endif; ?>

    <script src="<?php echo e(asset('backend/js/custom.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/js/dlabnav-init.js')); ?>"></script>

    <script src="<?php echo e(asset('backend/vendor/toastr/js/toastr.min.js')); ?>"></script>
    <!-- All init script -->
    <script src="<?php echo e(asset('backend/js/plugins-init/toastr-init.js')); ?>"></script>
    <?php echo Toastr::message(); ?>


    <?php echo $__env->yieldPushContent('js'); ?>

    <?php if(!Request::is('login') && !Request::is('password/*')): ?>
        <script>
            jQuery(document).ready(function() {
                setTimeout(function() {
                    dlabSettingsOptions.version = 'dark';
                    new dlabSettings(dlabSettingsOptions);
                }, 500)
            });
        </script>
    <?php endif; ?>

    
    
    

    <div class="fixed-bottom">
        
    </div>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\donating-app\resources\views/layouts/user/app.blade.php ENDPATH**/ ?>