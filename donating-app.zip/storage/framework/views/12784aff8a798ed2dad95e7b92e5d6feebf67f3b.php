<div class="dlabnav">
    <div class="dlabnav-scroll">
        <div class="dropdown header-profile2" style="margin-left: 20px !important;">
            <div class="header-info2 d-inline-flex align-items-center">
                <img class="rounded-circle" src="<?php echo e(Auth::user()->image == !null ? asset('storage/user/' . Auth::user()->image) : asset('frontend/img/avatar.svg')); ?>" alt="" />
                <div class="d-flex align-items-center sidebar-info">
                    <div>
                        <span class="font-w400 d-block"><?php echo e(Auth::user()->name); ?></span>
                        <small class="d-block text-danger"><strong><?php echo e(Auth::user()->is_active ? 'Active' : 'Inactive Account'); ?></strong></small>
                        <small class="font-w400 d-block">User ID: <?php echo e(Auth::user()->username); ?></small>
                        <small class="font-w400 d-none d-lg-block">E-mail: <?php echo e(Auth::user()->email); ?></small>
                    </div>
                </div>
            </div>
        </div>
        <ul class="metismenu" id="menu">
            <li>
                <a href="<?php echo e(route('user.dashboard')); ?>">
                    <i class="flaticon-025-dashboard"></i>
                    <span class="nav-text">Dashboard</span>
                </a>
            </li>
            <li>
                <a class="has-arrow " href="javascript:void()" aria-expanded="false">
                    <i class="fas fa-credit-card"></i>
                    <span class="nav-text">Shelf</span>
                </a>
                <ul aria-expanded="false">
                    <?php
                        $categories = \App\Models\Category::where('status', 1)->get();
                    ?>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(route('category.index', $category->id)); ?>"><?php echo e($category->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </li>
            <li>
                <a class="has-arrow " href="javascript:void()" aria-expanded="false">
                    <i class="fas fa-credit-card"></i>
                    <span class="nav-text">Ordered Items</span>
                </a>
                <ul aria-expanded="false">
                    <li><a href="<?php echo e(route('my-order.pending.request')); ?>">Pending</a></li>
                    <li><a href="<?php echo e(route('my-order.approved.request')); ?>">Approved</a></li>
                    <li><a href="<?php echo e(route('my-order.rejected.request')); ?>">Rejected</a></li>
                </ul>
            </li>
            <li>
                <a class="has-arrow " href="javascript:void()" aria-expanded="false">
                    <i class="fas fa-credit-card"></i>
                    <span class="nav-text">Donate</span>
                </a>
                <ul aria-expanded="false">
                    <li><a href="<?php echo e(route('donation.create')); ?>">Donate Product</a></li>
                    <li><a href="<?php echo e(route('donation.pending')); ?>">Pending</a></li>
                    <li><a href="<?php echo e(route('donation.approved')); ?>">Approved</a></li>
                    <li><a href="<?php echo e(route('donation.rejected')); ?>">Rejected</a></li>
                </ul>
            </li>
            <li>
                <a class=" " href="<?php echo e(route('donation.index')); ?>" aria-expanded="false">
                    <i class="fas fa-credit-card"></i>
                    <span class="nav-text">Total Sales Item</span>
                </a>
            </li>
            <li>
                <a class="has-arrow " href="javascript:void()" aria-expanded="false">
                    <i class="fas fa-credit-card"></i>
                    <span class="nav-text">Buyer Request</span>
                </a>
                <ul aria-expanded="false">
                    <li><a href="<?php echo e(route('buyer-request.pending.request')); ?>">Pending</a></li>
                    <li><a href="<?php echo e(route('buyer-request.completed.request')); ?>">Completed</a></li>
                    <li><a href="<?php echo e(route('buyer-request.rejected.request')); ?>">Rejected</a></li>
                </ul>
            </li>
            <li>
                <a href="<?php echo e(route('sponsored-shop.index')); ?>" aria-expanded="false">
                    <i class="fas fa-user"></i>
                    <span class="nav-text">Sponsored Shop</span>
                </a>
            </li>
            <li>
                <a href="#logout" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                    <i class="fas fa-sign-out-alt"></i>
                    <span class="ms-2">Logout </span>
                </a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>
            </li>
        </ul>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\donating-app\resources\views/layouts/user/sidebar.blade.php ENDPATH**/ ?>