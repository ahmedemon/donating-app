<?php $__env->startPush('css'); ?>
	<link rel="stylesheet" href="<?php echo e(asset('frontend/css/owl.carousel.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
	<div class="container-fluid">
		<div class="loop owl-carousel">
			<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="item card rounded-0">
					<a class="text-decoration-none" href="">
						<div class="p-0 border border-danger rounded-0 bbb_viewed_item discount d-flex flex-column align-items-center justify-content-center text-center">
						    <div class="">
						        <img class="d-block" height="280" src="<?php echo e(asset('storage/donation/'. $product->images)); ?>" alt="">
						    </div>
						    <div class="bbb_viewed_content text-center py-2 mt-0">
						        <div class="bbb_viewed_price">Points to get : <?php echo e($product->point); ?></div>
						        <p class="small my-0 text-uppercase text-dark"><?php echo e($product->title); ?></p>
                                <?php if(auth()->guard()->check()): ?>
                                    <?php if($product->user_id == Auth::user()->id): ?>
                                        <a href="<?php echo e(route('donation.pending'. $product->id)); ?>" class="btn btn-sm rounded-0 btn-danger">View</a>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('my-order.buy.request', $product->id)); ?>" class="btn btn-sm rounded-0 btn-danger">Get Now</a>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <a href="<?php echo e(route('my-order.buy.request', $product->id)); ?>" class="btn btn-sm rounded-0 btn-danger">Get Now</a>
                                <?php endif; ?>
						        <div class="bbb_viewed_name"></div>
							</div>
						</div>
					</a>
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
  <script src="<?php echo e(asset('frontend/js/owl.carousel.min.js')); ?>"></script>
  <script>
    $('.loop').owlCarousel({
    	dots: false,
        autoplay: true,
        mergeFit: true,
        startPosition: 1,
        smartSpeed: 250,
        center: true,
        items:2,
        loop:true,
        margin:10,
        responsive:{
            600:{
                items:7
            }
        }
    });
  </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\donating-app\resources\views/dashboard.blade.php ENDPATH**/ ?>